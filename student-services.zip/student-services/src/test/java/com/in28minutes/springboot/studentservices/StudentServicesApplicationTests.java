package com.in28minutes.springboot.studentservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
